// Import required packages
import express from 'express'; 
import bodyParser from 'body-parser'; 
import session from 'express-session'; 
import fileUpload from 'express-fileupload'; 
import axios from 'axios'; 
import path, { dirname } from 'path';
import { fileURLToPath } from 'url'; 
import { connectToDatabase, usersCollection, contentsCollection, followsCollection, uploadsCollection, pokemonCollection } from './db.mjs'; // Custom database connection and collections

// Setup paths for current directory
const __dirname = dirname(fileURLToPath(import.meta.url)); // To get the directory name of the current file

const app = express(); // Create an instance of the express app
const port = 8080; // Set the port number

// Middleware setup
app.use(express.static('public'));  // Serve static files (like images, CSS, JS) from the 'public' directory
app.use(bodyParser.json());  // Middleware to parse incoming JSON data
app.use(session({
  secret: 'CSt 2120 secret', // Secret key to sign session cookies
  cookie: { maxAge: 60000 },  // Session cookie will expire after 1 minute
  resave: false,
  saveUninitialized: true
}));
app.use(fileUpload());  // Middleware to handle file uploads

// Connect to the database 
connectToDatabase();

// Login and authentication routes
app.get('/M00812299/login', (req, res) => {
  // Check if the user is logged in by verifying the session
  res.json({ loggedIn: !!req.session.username, username: req.session.username });
});

app.post('/M00812299/login', async (req, res) => {
  const { username, password } = req.body; // Get login credentials from the request body
  if (!username || !password) {
    return res.json({ registration: false, message: "Username and password are required" });
  }

  // Check if the user exists in the database
  const foundUser = await usersCollection.findOne({ username, password });
  if (!foundUser) {
    return res.json({ login: false, message: 'Invalid username or password' });
  }

  // Set the session with the username
  req.session.username = username;
  res.json({ loggedIn: true, message: "You have logged in" });
});

app.delete('/M00812299/login', (req, res) => {
  // Logout route, destroy the session
  req.session.destroy();
  res.json({ loggedIn: false, message: "Logged out successfully" });
});

// User registration and management routes
app.post('/M00812299/users', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.json({ registration: false, message: "Username and password are required" });
  }

  // Check if the username is already taken
  if (await usersCollection.findOne({ username })) {
    return res.json({ registration: false, message: "Username already taken" });
  }

  // Insert the new user into the database
  await usersCollection.insertOne({ username, password });
  res.json({ registration: true, message: "User registered successfully" });
});

app.get('/M00812299/users', async (req, res) => {
  // Get all users from the database
  const users = await usersCollection.find({}).toArray();
  res.json(users);
});

app.delete('/M00812299/users', async (req, res) => {
  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ message: "Username is required" });
  }

  // Delete the user and related data (followers, followed users, content)
  const userResult = await usersCollection.deleteOne({ username });
  const followsResult = await followsCollection.deleteMany({ $or: [{ follower: username }, { following: username }] });
  const contentsResult = await contentsCollection.deleteMany({ username });

  res.json({
    message: "User deleted successfully",
    userDeleted: userResult.deletedCount,
    followsDeleted: followsResult.deletedCount,
    contentsDeleted: contentsResult.deletedCount
  });
});

// Content management routes
app.post('/M00812299/contents', async (req, res) => {
  const { username, title, text } = req.body;
  if (!username || !title || !text) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    // Add new content to the database
    const newContent = { username, title, text };
    await contentsCollection.insertOne(newContent);
    res.status(201).json({ message: "Content added successfully" });
  } catch (err) {
    console.error('Error adding content:', err);
    res.status(500).json({ message: "An error occurred while adding content" });
  }
});

app.get('/M00812299/contents', async (req, res) => {
  // Get the content of followed users
  if (!req.session.username) {
    return res.json({ loggedIn: false, message: "You need to log in first" });
  }

  const currentUser = req.session.username;
  const followingUsers = await followsCollection.find({ follower: currentUser }).toArray();
  const followingUsernames = followingUsers.map(f => f.following);

  const contents = await contentsCollection.find({ username: { $in: followingUsernames } }).toArray();
  res.json(contents);
});

// Following/unfollowing users
app.post('/M00812299/follow', async (req, res) => {
  if (!req.session.username) {
    return res.json({ followed: false, message: "You need to log in first" });
  }

  const { username } = req.body;
  if (!username) {
    return res.json({ followed: false, message: "Username to follow is required" });
  }

  const userToFollow = await usersCollection.findOne({ username });
  if (!userToFollow) {
    return res.json({ followed: false, message: "User does not exist" });
  }

  const follow = { follower: req.session.username, following: username };
  await followsCollection.insertOne(follow);

  res.json({ followed: true, message: `You are now following ${username}`, follow });
});

app.delete('/M00812299/follow', async (req, res) => {
  if (!req.session.username) {
    return res.json({ loggedIn: false, message: "You need to log in first" });
  }

  const { username } = req.body;
  if (!username) {
    return res.json({ unfollowed: false, message: "Username to unfollow is required" });
  }

  const followRelationship = await followsCollection.findOne({
    follower: req.session.username,
    following: username
  });

  if (!followRelationship) {
    return res.json({ unfollowed: false, message: "You are not following this user" });
  }

  await followsCollection.deleteOne({ follower: req.session.username, following: username });
  res.json({ unfollowed: true, message: `You have unfollowed ${username}` });
});

// Searches users
app.get('/M00812299/users/search', async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.json({ search: false, message: "Missing search query" });
  }

  try {
    const results = await usersCollection.find({ username: { $regex: `\\b${query}\\b`, $options: 'i' } }).toArray();
    if (results.length === 0) {
      return res.json({ search: false, message: "User doesn't exist." });
    }
    res.json({ search: true, results });
  } catch (err) {
    console.error('Error searching for users:', err);
    res.status(500).json({ search: false, message: "An error occurred while searching for users." });
  }
});
//Searches contents
app.get('/M00812299/contents/search', async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.json({ search: false, message: "Missing search query" });
  }

  try {
    const results = await contentsCollection.find({ title: { $regex: `^${query}$`, $options: 'i' } }).toArray();
    if (results.length === 0) {
      return res.json({ search: false, message: "Content doesn't exist." });
    }
    res.json({ search: true, results });
  } catch (err) {
    console.error('Error searching for contents:', err);
    res.status(500).json({ search: false, message: "An error occurred while searching for contents." });
  }
});

// File upload route
app.post('/M00812299/upload', async (req, res) => {
  try {
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).json({ upload: false, error: "Files missing" });
    }

    const myFile = req.files.myFile;
    const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!allowedMimeTypes.includes(myFile.mimetype)) {
      return res.status(400).json({ upload: false, error: "Invalid file type" });
    }

    // Save the file to the 'public/uploads' directory
    const uploadPath = path.join(__dirname, 'public', 'uploads', myFile.name);
    await myFile.mv(uploadPath);

    // Save the file details to the database
    const result = await uploadsCollection.insertOne({
      filename: myFile.name,
      path: `/uploads/${myFile.name}`,
      createdAt: new Date(),
    });

    res.json({
      message: "Successfully uploaded file",
      fileId: result.insertedId,
      filePath: `/uploads/${myFile.name}`
    });
  } catch (err) {
    console.error('Error uploading file: ', err);
    res.status(500).json({ error: 'There was an error uploading the file' });
  }
});

// Fetch Pokémon data
app.get('/M00812299/pokemon', async (req, res) => {
  const pokemonName = "pikachu";  // Example Pokémon to fetch

  try {
    // First check if the Pokémon data exists in the database
    const cachedPokemon = await pokemonCollection.findOne({ name: pokemonName.toLowerCase() });
    if (cachedPokemon) {
      return res.json(cachedPokemon); // Return the cached data
    }

    // Fetch the Pokémon data from the external API if not found in the database
    const response = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemonName.toLowerCase()}`);
    const data = response.data;

    const pokemonData = {
      name: data.name,
      sprite: data.sprites.front_default,
    };

    // Save the Pokémon data to the database
    await pokemonCollection.updateOne(
      { name: pokemonData.name },
      { $set: pokemonData },
      { upsert: true }
    );

    res.json(pokemonData);  // Return the fetched Pokémon data
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ message: 'An error occurred while fetching Pokémon data.' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
