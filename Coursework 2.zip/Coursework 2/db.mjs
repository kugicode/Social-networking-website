import { MongoClient, ServerApiVersion, ObjectId } from "mongodb";
//Mongodb connetion.
const connectionURI = "mongodb://localhost:27017/";
const client = new MongoClient(connectionURI, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: false,
    deprecationErrors: true
  }
});

let database, usersCollection, contentsCollection, followsCollection, uploadsCollection, pokemonCollection;

//Checks to see if mongodb is connected.
async function connectToDatabase() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    database = client.db("cst2024");
    //Collection in mongodb
    usersCollection = database.collection("users");
    contentsCollection = database.collection("contents");
    followsCollection = database.collection("follows");
    uploadsCollection = database.collection("upload");
    pokemonCollection = database.collection("pokemon");
  } catch (err) {
    console.error('Failed to connect to MongoDB', err);
  }
}

// Export the functions and collections
export { connectToDatabase, usersCollection, contentsCollection, followsCollection, uploadsCollection, pokemonCollection,  ObjectId };
