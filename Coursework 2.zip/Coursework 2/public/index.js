// Function to display a modal by setting its display style to 'block'
function showModal(modalId) {
    document.getElementById(modalId).style.display = "block";
}

// Function to close the modal by setting its display style to 'none'
function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

// Close the modal when clicking outside of it
window.onclick = function(event) {
    const modals = document.getElementsByClassName("modal");
    for (let i = 0; i < modals.length; i++) {
        // Close modal if the click is on the modal background
        if (event.target == modals[i]) {
            modals[i].style.display = "none";
        }
    }
}

// Function to register a new user
async function register() {
    const username = document.querySelector("#RegUserInput").value;
    const password = document.querySelector("#RegPasswordInput").value;
    const user = { username, password };
    const feedBackDiv = document.getElementById('AFeedbackDiv');
    
    try {
        const response = await fetch('/M00812299/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user)
        });
        const result = await response.json();
        console.log(result);

        // Display feedback based on registration success or failure
        if (result.registration) {
            feedBackDiv.innerHTML = 'User registered successfully.';
        } else {
            feedBackDiv.innerHTML = result.message;
        }
    } catch (err) {
        console.log("Registration error " + err);
        feedBackDiv.innerHTML = 'An error occurred while trying to register.';
    }
}

// Function to log in a user
async function login() {
    const username = document.querySelector("#LoginUserInput").value;
    const password = document.querySelector("#LoginPasswordInput").value;
    const user = { username, password };
    const anotherFeedBackDiv = document.getElementById('FeedbackDiv');
    
    try {
        const response = await fetch('/M00812299/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user)
        });
        const result = await response.json();
        console.log(result);

        // Display feedback and update the feed if login is successful
        if (result.loggedIn) {
            anotherFeedBackDiv.innerHTML = 'You have successfully logged in.';
            fetchFeed(); // Call fetchFeed to update the feed
        } else {
            anotherFeedBackDiv.innerHTML = result.message;
        }
    } catch (err) {
        console.log("Error logging in " + err);
        anotherFeedBackDiv.innerHTML = 'An error occurred while trying to log in.';
    }
}

// Function to follow a user
async function followUser() {
    const FollowFeedbackDiv = document.querySelector("#FollowFeedbackDiv");
    const username = document.querySelector("#FollowInput").value; // Access the value correctly
    const user = { username }; // Create the user object correctly

    try {
        const response = await fetch('/M00812299/follow', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user) // Send the user object directly
        });
        const result = await response.json();
        console.log(result);

        // Display feedback based on success or failure of follow operation
        if (result.followed) {
            FollowFeedbackDiv.innerHTML = "Followed successfully.";
            fetchFeed(); // Call fetchFeed to update the feed
        } else {
            FollowFeedbackDiv.innerHTML = result.message || "Failed to follow the user.";
        }
    } catch (error) {
        console.error('Follow error:', error);
        FollowFeedbackDiv.innerHTML = "An error occurred while trying to follow the user.";
    }
}

// Function to unfollow a user
async function unFollowUser() {
    const userToUnFollow = document.querySelector("#UnFollowInput").value;
    const req = { username: userToUnFollow };
    const UnFollowFeedbackDiv = document.querySelector("#UnFollowFeedbackDiv");

    try {
        const response = await fetch('/M00812299/follow', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(req)
        });
        const result = await response.json();
        console.log(result);

        // Display feedback based on success or failure of unfollow operation
        if (result.unfollowed) {
            UnFollowFeedbackDiv.innerHTML = "Unfollowed successfully.";
            fetchFeed(); // Call fetchFeed to update the feed
        } else {
            UnFollowFeedbackDiv.innerHTML = result.message || "Failed to unfollow the user.";
        }
    } catch (err) {
        console.error('Error:', err);
        UnFollowFeedbackDiv.innerHTML = "An error occurred while trying to unfollow the user.";
    }
}

// Function to search for users
async function searchUsers() {
    const searchTerm = document.querySelector('#SearchInput').value;
    const SearchResultsDiv = document.querySelector('#SearchResults');

    if (!searchTerm) {
        SearchResultsDiv.innerHTML = "Please enter a search term.";
        return;
    }

    try {
        const response = await fetch('/M00812299/users/search?q=' + encodeURIComponent(searchTerm));
        const result = await response.json();
        console.log(result);

        // Display search results or a message if no results are found
        if (result.search === false) {
            SearchResultsDiv.innerHTML = `<li>${result.message}</li>`;
        } else {
            let resStr = "";
            for (let user of result.results) {
                resStr += `<li>${user.username} <button onclick="follow('${user.username}')">Follow</button></li>`;
            }
            SearchResultsDiv.innerHTML = resStr;
        }
    } catch (err) {
        console.error('Error searching for users:', err);
        SearchResultsDiv.innerHTML = "<li>An error occurred while searching for users.</li>";
    }
}

// Function to follow a user (called from the search results)
async function follow(username) {
    const FollowUserDiv = document.querySelector("#FollowUser");
    try {
        const response = await fetch('/M00812299/follow', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username })
        });
        const result = await response.json();
        console.log(result);

        // Handle user not logged in or follow failure
        if (result.loggedIn === false) {
            FollowUserDiv.innerHTML = result.message || "You need to log in first.";
            return;
        } else if (result.followed) {
            FollowUserDiv.innerHTML = "Followed successfully.";
            fetchFeed(); // Call fetchFeed to update the feed
        } else {
            FollowUserDiv.innerHTML = result.message || "Failed to follow the user.";
        }
    } catch (error) {
        console.error('Follow error:', error);
        FollowUserDiv.innerHTML = "An error occurred while trying to follow the user.";
    }
}

// Function to fetch and display feed contents from followed users
async function fetchFeed() {
    const FeedResultsDiv = document.querySelector("#FeedResults");

    try {
        const response = await fetch('/M00812299/contents', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        const result = await response.json();
        console.log(result);

        // Check if the user is logged in
        if (result.loggedIn === false) {
            FeedResultsDiv.innerHTML = result.message || "You need to log in first.";
            return;
        }

        // Display content from followed users
        if (result.length > 0) {
            let resStr = "";
            for (let content of result) {
                resStr += `<div class="content-item">
                               <h3>${content.username}</h3>
                               <h4>${content.title}</h4>
                               <p>${content.text}</p>
                           </div>`;
            }
            FeedResultsDiv.innerHTML = resStr;
        } else {
            FeedResultsDiv.innerHTML = "No content available from followed users.";
        }
    } catch (err) {
        console.error('Error fetching feed:', err);
        FeedResultsDiv.innerHTML = "An error occurred while fetching the feed.";
    }
}

// Function to search blog contents by exact title
async function searchBlogContents() {
    const searchTerm = document.querySelector("#BlogSearchInput").value;
    const BlogSearchResultsDiv = document.querySelector("#BlogSearchResults");

    if (!searchTerm) {
        BlogSearchResultsDiv.innerHTML = "Please enter a search term.";
        return;
    }

    try {
        const response = await fetch('/M00812299/contents/search?q=' + encodeURIComponent(searchTerm));
        const result = await response.json();
        console.log(result);

        // Display search results or a message if no content is found
        if (result.search === false) {
            BlogSearchResultsDiv.innerHTML = result.message || "No content found.";
        } else {
            let resStr = "";
            for (let content of result.results) {
                resStr += `<div class="content-item">
                           <h3>${content.title}</h3>
                           <p>${content.text}</p>
                           <p><strong>By:</strong> ${content.username}</p>
                         </div>`;
            }
            BlogSearchResultsDiv.innerHTML = resStr;
        }
    } catch (err) {
        console.error('Error searching blog contents:', err);
        BlogSearchResultsDiv.innerHTML = "An error occurred while searching the contents.";
    }
}

// Function to handle file upload
let serverResponse = document.getElementById("ServerResponse");
let profileImage = document.getElementById("ProfileImage");

async function uploadFile() {
    serverResponse.innerHTML = "";

    let fileArray = document.getElementById("FileInput").files;
    if (fileArray.length !== 1) {
        serverResponse.innerHTML = "Please select a file to upload.";
        return;
    }

    const formData = new FormData();
    formData.append('myFile', fileArray[0]);

    try {
        const response = await fetch('/M00812299/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.error) {
            serverResponse.innerHTML = result.error;
        } else {
            serverResponse.innerHTML = "File uploaded successfully";
            profileImage.src = result.filePath; // Set the src of the image element to the file path
        }
    } catch (error) {
        serverResponse.innerHTML = "Error uploading file: " + error.message;
    }
}

// Function to fetch Pokémon data
async function fetchPokemon() {
    try {
        const response = await fetch('/M00812299/pokemon');
        if (!response.ok) {
            throw new Error("Could not fetch Pokémon data");
        }

        const data = await response.json();
        const imgElement = document.getElementById("pokemonSprite");

        // Set the Pokémon sprite source and display it
        imgElement.src = data.sprite;
        imgElement.style.display = "block";
    } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
    }
}

// Call fetchFeed on page load to load content from followed users
document.addEventListener('DOMContentLoaded', fetchFeed);
